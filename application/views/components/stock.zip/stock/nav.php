<div class="container-fluid none" <?php echo $subMenu; ?> style="margin-bottom: 10px;">
    <div class="row">
		<a href="<?php echo site_url('stock/stock/transfer'); ?>" class="btn btn-default" id="add-new">
			Stock Transfer
		</a>
		<a href="<?php echo site_url('stock/stock/history'); ?>" class="btn btn-default" id="all-history">
		    History	Of Stock Transfer 
		</a>
    </div>
</div>
